<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Meus Pedidos
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-2xl font-bold mb-6">Seu Histórico de Compras</h3>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border">
                            <thead class="bg-gray-200">
                                <tr>
                                    <th class="py-2 px-4 border-b">Data</th>
                                    <th class="py-2 px-4 border-b">Rifa</th>
                                    <th class="py-2 px-4 border-b">Qtd. Cotas</th>
                                    <th class="py-2 px-4 border-b">Valor Total</th>
                                    <th class="py-2 px-4 border-b">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="text-center hover:bg-gray-50">
                                        <td class="py-2 px-4 border-b"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                                        <td class="py-2 px-4 border-b text-left"><?php echo e($order->raffle->title); ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo e($order->ticket_quantity); ?></td>
                                        <td class="py-2 px-4 border-b">R$ <?php echo e(number_format($order->total_amount, 2, ',', '.')); ?></td>
                                        <td class="py-2 px-4 border-b">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                                <?php echo e($order->status === 'paid' ? 'bg-green-100 text-green-800' : ''); ?>

                                                <?php echo e($order->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                                <?php echo e($order->status === 'expired' ? 'bg-red-100 text-red-800' : ''); ?>

                                                <?php echo e($order->status === 'cancelled' ? 'bg-gray-100 text-gray-800' : ''); ?>">
                                                <?php echo e(ucfirst($order->status)); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="py-4 text-center text-gray-500">Você ainda não fez nenhum pedido.</td>
                                    </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\sistema-rifas\resources\views/livewire/user/my-orders.blade.php ENDPATH**/ ?>