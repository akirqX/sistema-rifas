<div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $raffles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raffle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300">
                        
                        <a href="<?php echo e(route('raffle.show', $raffle)); ?>">
    <div class="aspect-w-16 aspect-h-9">
        <img class="w-full h-full object-center object-cover"
             src="<?php echo e($raffle->getFirstMediaUrl('raffles') ?: 'https://via.placeholder.com/1600x900.png?text=Sem+Imagem'); ?>"
             alt="Imagem da rifa <?php echo e($raffle->title); ?>">
    </div>
</a>
                        <div class="p-6">
                            <h3 class="text-xl font-bold mb-2 truncate"><?php echo e($raffle->title); ?></h3>
                            <p class="text-gray-700 text-sm mb-4 h-10"><?php echo e(Str::limit($raffle->description, 100)); ?></p>

                            <div class="mb-4">
                                <?php
                                    $sold = $raffle->tickets()->where('status', 'paid')->count();
                                    $total = $raffle->total_tickets;
                                    $percentage = $total > 0 ? ($sold / $total) * 100 : 0;
                                ?>
                                <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                    <div class="bg-green-600 h-2.5 rounded-full" style="width: <?php echo e($percentage); ?>%"></div>
                                </div>
                                <span class="text-xs text-gray-600 mt-1"><?php echo e($sold); ?> de <?php echo e($total); ?> cotas vendidas</span>
                            </div>

                            <div class="flex justify-between items-center mt-6">
                                <span class="text-2xl font-bold text-green-500">R$ <?php echo e(number_format($raffle->ticket_price, 2, ',', '.')); ?></span>
                                <a href="<?php echo e(route('raffle.show', $raffle)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg">
                                    Participar
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center py-12">
                        <p class="text-gray-500">Nenhuma rifa ativa no momento. Volte em breve!</p>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\sistema-rifas\resources\views/livewire/raffles/showcase.blade.php ENDPATH**/ ?>