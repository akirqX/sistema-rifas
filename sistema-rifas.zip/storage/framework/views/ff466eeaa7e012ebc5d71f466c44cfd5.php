<div>
    <div class="container mx-auto px-4 py-16">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">

            
            <div class="bg-panel-dark border border-border-subtle rounded-lg p-8">
                <img src="<?php echo e($product->getFirstMediaUrl('product_images', 'default')); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-auto object-contain">
            </div>

            
            <div>
                <h1 class="text-4xl font-extrabold text-white"><?php echo e($product->name); ?></h1>
                <p class="text-xl text-text-muted mt-2"><?php echo e($product->wear); ?></p>

                <p class="text-lg text-text-muted mt-6">
                    <?php echo e($product->description ?? 'Nenhuma descrição adicional para este item.'); ?>

                </p>

                <div class="my-8">
                    <p class="text-4xl font-bold text-white">R$ <?php echo e(number_format($product->price, 2, ',', '.')); ?></p>
                </div>

                <div class="flex items-center gap-4">
                    
                    <a href="#" class="btn-prodgio btn-primary flex-grow text-center">Comprar Agora</a>
                    <!--[if BLOCK]><![endif]--><?php if($product->steam_inspect_link): ?>
                        <a href="<?php echo e($product->steam_inspect_link); ?>" target="_blank" class="btn-prodgio btn-secondary text-center">Inspecionar no Jogo</a>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\sistema-rifas\resources\views/livewire/skins/show-page.blade.php ENDPATH**/ ?>