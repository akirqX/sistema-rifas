<?php

namespace App\Console\Commands;

use App\Models\Order;
use App\Models\Ticket;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ReleaseExpiredTickets extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tickets:release-expired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Libera tickets de pedidos expirados de volta para disponível';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Iniciando liberação de tickets expirados...');

        $expiredOrders = Order::where('status', 'pending')
            ->where('expires_at', '<', now())
            ->get();

        if ($expiredOrders->isEmpty()) {
            $this->info('Nenhum pedido expirado encontrado.');
            return 0;
        }

        $totalTicketsReleased = 0;

        foreach ($expiredOrders as $order) {
            DB::transaction(function () use ($order, &$totalTicketsReleased) {
                // Atualizar status do pedido para expirado
                $order->update(['status' => 'expired']);

                // Liberar tickets de volta para disponível
                $ticketsReleased = Ticket::where('order_id', $order->id)
                    ->where('status', 'reserved')
                    ->update([
                        'status' => 'available',
                        'order_id' => null,
                        'user_id' => null
                    ]);

                $totalTicketsReleased += $ticketsReleased;

                $this->info("Pedido #{$order->id} expirado. {$ticketsReleased} tickets liberados.");
            });
        }

        $this->info("Processo concluído. Total de {$totalTicketsReleased} tickets liberados de {$expiredOrders->count()} pedidos expirados.");

        return 0;
    }
}

