<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product; // <-- 1. IMPORTAMOS O MODEL PRODUCT
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use MercadoPago\Client\Payment\PaymentClient;
use MercadoPago\MercadoPagoConfig;

class PaymentWebhookController extends Controller
{
    public function handle(Request $request)
    {
        Log::info('Mercado Pago Webhook Received:', $request->all());

        try {
            // Validação básica de segurança
            if (!$this->isValidWebhook($request)) {
                Log::warning('Webhook rejeitado: validação de segurança falhou');
                return response()->json(['status' => 'invalid'], 400);
            }

            MercadoPagoConfig::setAccessToken(config('services.mercadopago.token'));
            $client = new PaymentClient();

            // Lida com o formato da simulação do painel
            if ($request->input('action') === 'payment.updated' && $request->input('id')) {
                $this->handleTestWebhook($request->input('id'), $client);
                return response()->json(['status' => 'success_test'], 200);
            }

            // Lida com notificações reais
            if ($request->input('type') === 'payment' && $request->input('data.id')) {
                $paymentId = $request->input('data.id');
                
                // Verificar se já processamos este pagamento (idempotência)
                $existingOrder = Order::where('transaction_id', $paymentId)
                    ->where('status', 'paid')
                    ->first();
                    
                if ($existingOrder) {
                    Log::info("Pagamento {$paymentId} já foi processado anteriormente");
                    return response()->json(['status' => 'already_processed'], 200);
                }
                
                $payment = $client->get($paymentId);

                if ($payment && $payment->status === 'approved') {
                    $order = Order::where('transaction_id', $payment->id)->where('status', 'pending')->first();

                    if ($order) {
                        $order->update(['status' => 'paid']);

                        // --- LÓGICA DE DECISÃO: É RIFA OU SKIN? ---
                        if ($order->product_id) {
                            // É um pedido de SKIN!
                            $product = Product::find($order->product_id);
                            if ($product) {
                                $product->status = 'sold'; // Marca a skin como vendida
                                $product->save();
                                Log::info("SUCESSO (Skin): Pedido Real #{$order->id} pago. Skin #{$product->id} marcada como vendida.");
                                // TODO: Disparar evento para notificar o admin para entregar a skin
                                // event(new SkinSold($order));
                            }
                        } else {
                            // É um pedido de RIFA (lógica original)
                            $order->tickets()->update(['status' => 'paid']);
                            Log::info("SUCESSO (Rifa): Pedido Real #{$order->id} foi pago e bilhetes atualizados.");
                        }
                    }
                } elseif ($payment && in_array($payment->status, ['cancelled', 'rejected', 'refunded', 'charged_back'])) {
                    // Lidar com pagamentos cancelados/rejeitados/estornados
                    $order = Order::where('transaction_id', $payment->id)->whereIn('status', ['pending', 'paid'])->first();
                    if ($order) {
                        $newStatus = in_array($payment->status, ['refunded', 'charged_back']) ? 'refunded' : 'failed';
                        $order->update(['status' => $newStatus]);
                        
                        // Liberar tickets se for uma rifa
                        if (!$order->product_id) {
                            $order->tickets()->update([
                                'status' => 'available',
                                'order_id' => null,
                                'user_id' => null
                            ]);
                        } else {
                            // Se for skin e foi estornado, marcar como disponível novamente
                            if (in_array($payment->status, ['refunded', 'charged_back'])) {
                                $product = Product::find($order->product_id);
                                if ($product) {
                                    $product->status = 'available';
                                    $product->save();
                                }
                            }
                        }
                        Log::info("Pagamento {$paymentId} foi {$payment->status}. Pedido #{$order->id} marcado como {$newStatus}.");
                    }
                } elseif ($payment && in_array($payment->status, ['in_process', 'pending'])) {
                    // Pagamentos em processamento - apenas logar, não alterar status
                    Log::info("Pagamento {$paymentId} está em processamento com status: {$payment->status}");
                }
            }

        } catch (\Exception $e) {
            Log::error("Erro no Webhook: " . $e->getMessage());
            return response()->json(['status' => 'error', 'message' => 'Internal server error'], 500);
        }

        return response()->json(['status' => 'success'], 200);
    }

    /**
     * Validação básica de segurança do webhook
     */
    protected function isValidWebhook(Request $request): bool
    {
        // Verificar se a requisição tem os campos necessários
        if (!$request->hasAny(['type', 'action']) || 
            (!$request->has('data.id') && !$request->has('id'))) {
            return false;
        }

        // Verificar assinatura X-Signature se disponível
        $signature = $request->header('X-Signature');
        if ($signature && config('services.mercadopago.webhook_secret')) {
            return $this->verifyWebhookSignature($request, $signature);
        }

        // Verificar IP de origem (opcional)
        if (config('services.mercadopago.verify_webhook_ip', false)) {
            return $this->isValidMercadoPagoIP($request->ip());
        }

        return true;
    }

    /**
     * Verifica a assinatura do webhook do Mercado Pago
     */
    protected function verifyWebhookSignature(Request $request, string $signature): bool
    {
        $secret = config('services.mercadopago.webhook_secret');
        if (!$secret) {
            return false;
        }

        // Extrair timestamp e hash da assinatura
        $parts = explode(',', $signature);
        $timestamp = null;
        $hash = null;

        foreach ($parts as $part) {
            $keyValue = explode('=', $part, 2);
            if (count($keyValue) === 2) {
                if ($keyValue[0] === 'ts') {
                    $timestamp = $keyValue[1];
                } elseif ($keyValue[0] === 'v1') {
                    $hash = $keyValue[1];
                }
            }
        }

        if (!$timestamp || !$hash) {
            return false;
        }

        // Verificar se o timestamp não é muito antigo (5 minutos)
        if (abs(time() - intval($timestamp)) > 300) {
            return false;
        }

        // Construir string para verificação
        $dataId = $request->input('data.id') ?? $request->input('id');
        $manifest = "id:{$dataId};request-id:{$request->header('X-Request-Id')};ts:{$timestamp};";
        
        // Calcular hash esperado
        $expectedHash = hash_hmac('sha256', $manifest, $secret);

        return hash_equals($expectedHash, $hash);
    }

    /**
     * Verifica se o IP é do Mercado Pago
     */
    protected function isValidMercadoPagoIP(string $ip): bool
    {
        // IPs do Mercado Pago (podem mudar, verificar documentação)
        $validIPs = [
            '209.225.49.0/24',
            '216.33.197.0/24',
            '216.33.196.0/24'
        ];

        foreach ($validIPs as $range) {
            if ($this->ipInRange($ip, $range)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Verifica se um IP está em um range CIDR
     */
    protected function ipInRange(string $ip, string $range): bool
    {
        if (strpos($range, '/') === false) {
            return $ip === $range;
        }

        list($subnet, $bits) = explode('/', $range);
        $ip = ip2long($ip);
        $subnet = ip2long($subnet);
        $mask = -1 << (32 - $bits);
        $subnet &= $mask;
        
        return ($ip & $mask) === $subnet;
    }

    /**
     * Lógica isolada para lidar apenas com as simulações do painel do Mercado Pago.
     */
    protected function handleTestWebhook(string $testPaymentId, PaymentClient $client)
    {
        Log::info("Simulação de Webhook detectada para o ID: {$testPaymentId}");

        // Pega o pedido pendente mais recente para simular a aprovação
        $order = Order::where('status', 'pending')->latest()->first();

        if ($order) {
            $order->update(['status' => 'paid', 'transaction_id' => $testPaymentId]);

            // --- 3. LÓGICA DE DECISÃO REPLICADA PARA TESTES ---
            if ($order->product_id) {
                // É um pedido de SKIN!
                $product = Product::find($order->product_id);
                if ($product) {
                    $product->status = 'sold';
                    $product->save();
                    Log::info("SUCESSO (Simulação de Skin): Pedido #{$order->id} pago. Skin #{$product->id} marcada como vendida.");
                }
            } else {
                // É um pedido de RIFA
                $order->tickets()->update(['status' => 'paid']);
                Log::info("SUCESSO (Simulação de Rifa): Pedido #{$order->id} foi pago e bilhetes atualizados.");
            }

        } else {
            Log::warning("Simulação de Webhook recebida, mas nenhum pedido pendente foi encontrado para testar.");
        }
    }
}
